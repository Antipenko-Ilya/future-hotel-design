const slides = [
    {
        name: 'first',
        src: './slideImages/slider_0.png'
    },
    {
        name: 'second',
        src: './slideImages/slider_1.png'
    },
    {
        name: 'third',
        src: './slideImages/slider_2.png'
    },
    {
        name: 'wof',
        src: './slideImages/slider_3.png'
    }
]

export default slides;