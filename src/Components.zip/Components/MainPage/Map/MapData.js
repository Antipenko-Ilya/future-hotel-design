export const Points = [
    {
        coords: {
            top: '42%',
            left: '13.5%'
        }
        
    },
    {
        coords: {
            top: '53%',
            left: '1%'
        }
    }
]