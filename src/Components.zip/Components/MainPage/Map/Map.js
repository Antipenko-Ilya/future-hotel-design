import React from 'react';
import styles from './Map.module.css'
import SectionTitle from '../../MicroAssets/SectionTitle/SectionTitle'

function Map() {


    return (
        <div className={styles.Map}>
           <SectionTitle title={'ГЕОГРАФИЯ ПРОЕКТОВ'}/>
        </div>
    )
}

export default Map;
