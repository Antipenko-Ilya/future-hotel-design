import React from 'react';
import styles from './Partners.module.css'
import SectionTitle from '../../MicroAssets/SectionTitle/SectionTitle'

export default function Partners() {


    return (
        <div className={styles.Partners}>
           <SectionTitle title={'ПАРТНЁРЫ'}/>
        </div>
    )
}


