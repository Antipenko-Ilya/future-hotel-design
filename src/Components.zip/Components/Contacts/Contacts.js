import React from 'react';
import styles from './Contacts.module.css';
// import globalStyles from '../../../globalStyles.module.css';

function Contacts(props) {


    return (
        <div className={styles.Contacts}>
            
        </div>
    )
}

export default Contacts;
